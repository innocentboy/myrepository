#include<ios>
main(int t,unsigned long long n){scanf("%d",&t);while(t--){scanf("%llu",&n);printf("%llu\n",n*(10*n*n+9*n+1));}}
