/*
USER: zobayer
TASK: RESN04
ALGO: ad-hoc
*/

#include <iostream>
using namespace std;

int main() {
	int t, n, a, i;
	cin >> t;
	while(t--) {
		cin >> n;
		for(i=0; i<n; i++) cin >> a;
		cout << "ALICE" << endl;
	}
	return 0;
}
